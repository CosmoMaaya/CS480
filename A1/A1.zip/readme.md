### Instruction

* To run the script, you need to unpact the data files under `./data/` folder. All the data file names are hardcoded in to the code so please make sure they have the original name from the web_site
* To run the scripts, make sure your working directory is the current directory, then just simply use `python3 [question].py` where questions is the question number (q1, q2, q3, q4) and you will see the corresponding graph saved to the current directory. Some questions will have terminal outputs, too. 